import { Toaster } from "@components/ui/toaster";
import { Toaster as Sonner } from "@components/ui/sonner";
import { TooltipProvider } from "@components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Outlet } from "react-router-dom";
import PageLayout from "@components/PageLayout";
import HomePage from "@pages/HomePage";
import ServicesPage from "@pages/ServicesPage";
import ProductsPage from "@pages/ProductsPage";
import ProductCategory from "@components/ProductCategory";
import AboutPage from "@pages/AboutPage";
import ContactPage from "@pages/ContactPage";
import NotFound from "@pages/NotFound";

// Admin imports
import AdminLayout from "@components/admin/AdminLayout";
import AdminDashboard from "@pages/admin/AdminDashboard";
import ProductsManagementPage from "@pages/admin/ProductsManagementPage";
import ProductFormPage from "@pages/admin/ProductFormPage";
import InquiriesPage from "@pages/admin/InquiriesPage";
import ContactSubmissionsPage from "@pages/admin/ContactSubmissionsPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<PageLayout><Outlet /></PageLayout>}>
            <Route index element={<HomePage />} />
            <Route path="/services" element={<ServicesPage />} />
            <Route path="/products" element={<ProductsPage />} />
            <Route path="/products/:categoryId" element={<ProductCategory />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Route>

          {/* Admin Routes */}
          <Route path="/admin" element={<AdminLayout><Outlet /></AdminLayout>}>
            <Route index element={<AdminDashboard />} />
            <Route path="products" element={<ProductsManagementPage />} />
            <Route path="products/:productId" element={<ProductFormPage />} />
            <Route path="products/new" element={<ProductFormPage />} />
            <Route path="inquiries" element={<InquiriesPage />} />
            <Route path="contacts" element={<ContactSubmissionsPage />} />
          </Route>

          {/* Catch-all route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
