
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export interface ProductInquiry {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  productId: string;
  subproductName?: string;
  status: "new" | "read" | "replied";
  date: string;
}

export const getAllInquiries = async (): Promise<ProductInquiry[]> => {
  const response = await axios.get(`${API_URL}/inquiries`);
  return response.data;
};

export const addInquiry = async (inquiry: {
  name: string;
  email: string;
  phone: string;
  productRequirement: string;
  additionalInfo?: string;
  productId: string;
  subproductName?: string;
}): Promise<ProductInquiry | null> => {
  const subject = inquiry.subproductName
    ? `Inquiry about ${inquiry.subproductName}`
    : "Product Inquiry";
    
  const message = `${inquiry.productRequirement}${
    inquiry.additionalInfo ? `\n\nAdditional Information: ${inquiry.additionalInfo}` : ""
  }`;

  const newInquiry = {
    name: inquiry.name,
    email: inquiry.email,
    phone: inquiry.phone,
    subject,
    message,
    productId: inquiry.productId,
    subproductName: inquiry.subproductName,
    status: "new" as const,
    date: new Date().toISOString()
  };

  const response = await axios.post(`${API_URL}/inquiries`, newInquiry);
  return response.data;
};

export const updateInquiryStatus = async (id: string, status: "new" | "read" | "replied"): Promise<ProductInquiry | null> => {
  try {
    const response = await axios.patch(`${API_URL}/inquiries/${id}/status`, { status });
    return response.data;
  } catch (error) {
    console.error("Error updating inquiry status:", error);
    return null;
  }
};

export const deleteInquiry = async (id: string): Promise<boolean> => {
  try {
    const response = await axios.delete(`${API_URL}/inquiries/${id}`);
    return response.data.success;
  } catch (error) {
    console.error("Error deleting inquiry:", error);
    return false;
  }
};
