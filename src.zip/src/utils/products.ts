
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

export interface Product {
  id: string;
  title: string;
  description: string;
  category: string;
  imageUrl: string;
  images?: string[];
  subproductImages?: Record<string, string>;
  isNew: boolean;
}

// Fallback data to use when API is unavailable
const fallbackProducts: Product[] = [
  {
    id: "1",
    title: "Industrial Valve",
    description: "High-quality industrial valve for fluid control applications",
    category: "valves",
    imageUrl: "https://images.unsplash.com/photo-1581092331428-0d661e9124c3",
    isNew: true
  },
  {
    id: "2",
    title: "Stainless Steel Pipe",
    description: "Durable stainless steel pipes for industrial applications",
    category: "pipes",
    imageUrl: "https://images.unsplash.com/photo-1581092584667-531cefb1be8e",
    isNew: false
  }
];

export const getAllProducts = async (): Promise<Product[]> => {
  try {
    const response = await axios.get(`${API_URL}/products`);
    if (!response.data || response.data.length === 0) {
      console.log("No products found in database, using fallback data");
      return fallbackProducts;
    }
    return response.data;
  } catch (error) {
    console.error("Error fetching products:", error);
    // Return fallback data when API is unavailable
    return fallbackProducts;
  }
};

export const getProductById = async (id: string): Promise<Product | null> => {
  try {
    const response = await axios.get(`${API_URL}/products/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Error fetching product ${id}:`, error);
    // Try to find product in fallback data
    const fallbackProduct = fallbackProducts.find(p => p.id === id);
    return fallbackProduct || null;
  }
};

export const addProduct = async (product: Omit<Product, "id">): Promise<Product | null> => {
  try {
    const response = await axios.post(`${API_URL}/products`, product);
    return response.data;
  } catch (error) {
    console.error("Error adding product:", error);
    throw new Error("Failed to add product");
  }
};

export const updateProduct = async (id: string, product: Omit<Product, "id">): Promise<Product | null> => {
  try {
    const response = await axios.put(`${API_URL}/products/${id}`, product);
    return response.data;
  } catch (error) {
    console.error(`Error updating product ${id}:`, error);
    throw new Error("Failed to update product");
  }
};

export const deleteProduct = async (id: string): Promise<boolean> => {
  try {
    // For fallback data (when API is down), handle deletion locally
    if (id === "1" || id === "2") {
      console.log("Using fallback deletion for product:", id);
      return true;
    }
    
    const response = await axios.delete(`${API_URL}/products/${id}`);
    return response.data.success;
  } catch (error) {
    console.error(`Error deleting product ${id}:`, error);
    
    // Special case for fallback data
    if (id === "1" || id === "2") {
      return true;
    }
    
    return false;
  }
};
