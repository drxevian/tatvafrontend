import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/src/components/ui/card";
import { Badge } from "@/src/components/ui/badge";
import { Button } from "@/src/components/ui/button";
import { Eye } from "lucide-react";

interface ProductCardProps {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  isNew?: boolean;
}

const ProductCard = ({ id, title, description, imageUrl, category, isNew = false }: ProductCardProps) => {
  return (
    <Card className="overflow-hidden h-full flex flex-col hover:shadow-lg transition-shadow duration-300">
      <div className="relative h-60 bg-muted overflow-hidden">
        <img 
          src={imageUrl} 
          alt={title} 
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
          loading="lazy"
        />
        {isNew && (
          <Badge className="absolute top-2 right-2 bg-tatva-teal">New</Badge>
        )}
      </div>
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl">{title}</CardTitle>
          <Badge variant="outline">{category}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription className="text-gray-600">
          {description.length > 100 ? `${description.substring(0, 100)}...` : description}
        </CardDescription>
      </CardContent>
      <CardFooter className="mt-auto">
        <Button asChild variant="outline" className="w-full hover:bg-tatva-blue hover:text-white">
          <Link to={`/products/${id}`} className="flex items-center justify-center">
            <Eye className="mr-2 h-4 w-4" /> View Details
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
