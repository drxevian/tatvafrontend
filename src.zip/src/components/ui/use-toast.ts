
import { useToast, toast } from "@/src/hooks/use-toast";

export { useToast, toast };
