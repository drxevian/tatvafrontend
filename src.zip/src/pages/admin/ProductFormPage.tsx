
import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";
import { ArrowLeft, Save, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { Product, getProductById, addProduct, updateProduct } from "@/utils/products";

interface ProductFormData {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  category: string;
  isNew: boolean;
  images: string[];
  subproductImages?: Record<string, string>;
}

const ProductFormPage = () => {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const isNewProduct = productId === "new";
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [formData, setFormData] = useState<ProductFormData>({
    id: nanoid(8),
    title: "",
    description: "",
    imageUrl: "",
    category: "",
    isNew: false,
    images: ["", "", ""],
    subproductImages: {},
  });

  const [subproducts, setSubproducts] = useState<Array<{name: string, imageUrl: string}>>([
    { name: "", imageUrl: "" }
  ]);

  useEffect(() => {
    const fetchProductData = async () => {
      if (!isNewProduct && productId) {
        try {
          setIsLoading(true);
          const product = await getProductById(productId);
          
          if (product) {
            setFormData({
              id: product.id,
              title: product.title,
              description: product.description,
              imageUrl: product.imageUrl,
              category: product.category,
              isNew: product.isNew || false,
              images: [...(product.images || []), "", "", ""].slice(0, 3),
              subproductImages: product.subproductImages || {},
            });
            
            // Parse the subproducts from the description
            const subproductsList = product.description
              .split(",")
              .map((item) => item.trim())
              .filter((item) => item.length > 0);
              
            // Create subproduct items with their images if available
            const subproductItems = subproductsList.map(name => {
              return {
                name,
                imageUrl: product.subproductImages?.[name] || ""
              };
            });
            
            // Add at least one empty entry if there are no subproducts
            setSubproducts(subproductItems.length > 0 ? subproductItems : [{ name: "", imageUrl: "" }]);
          }
        } catch (error) {
          console.error("Error fetching product:", error);
          toast({
            title: "Error",
            description: "Failed to load product data. Please try again.",
            variant: "destructive",
          });
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchProductData();
  }, [productId, isNewProduct, toast]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCheckboxChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, isNew: checked }));
  };

  const handleImageChange = (index: number, value: string) => {
    const updatedImages = [...formData.images];
    updatedImages[index] = value;
    setFormData((prev) => ({ ...prev, images: updatedImages }));
  };

  const handleSubproductChange = (index: number, field: 'name' | 'imageUrl', value: string) => {
    const updatedSubproducts = [...subproducts];
    updatedSubproducts[index][field] = value;
    setSubproducts(updatedSubproducts);
  };

  const addSubproduct = () => {
    setSubproducts([...subproducts, { name: "", imageUrl: "" }]);
  };

  const removeSubproduct = (index: number) => {
    if (subproducts.length > 1) {
      setSubproducts(subproducts.filter((_, i) => i !== index));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    // Build the description from subproducts
    const description = subproducts
      .filter(sub => sub.name.trim() !== "")
      .map(sub => sub.name.trim())
      .join(", ");
    
    // Build subproductImages object
    const subproductImages: Record<string, string> = {};
    subproducts.forEach(sub => {
      if (sub.name.trim() && sub.imageUrl.trim()) {
        subproductImages[sub.name.trim()] = sub.imageUrl.trim();
      }
    });
    
    // Update the main images (remove empty ones)
    const filteredImages = formData.images.filter(img => img.trim() !== "");
    
    // Create final product object
    const finalProduct = {
      ...formData,
      description,
      images: filteredImages.length > 0 ? filteredImages : [formData.imageUrl],
      subproductImages: Object.keys(subproductImages).length > 0 ? subproductImages : undefined
    };
    
    try {
      let result;
      if (isNewProduct) {
        // Remove ID as the server will generate one
        const { id, ...productWithoutId } = finalProduct;
        result = await addProduct(productWithoutId);
        toast({
          title: "Product created",
          description: `"${finalProduct.title}" has been created successfully.`,
        });
      } else {
        result = await updateProduct(finalProduct.id, finalProduct);
        toast({
          title: "Product updated",
          description: `"${finalProduct.title}" has been updated successfully.`,
        });
      }
      
      console.log(isNewProduct ? "Product created:" : "Product updated:", result);
      navigate("/admin/products");
    } catch (error) {
      console.error(isNewProduct ? "Error creating product:" : "Error updating product:", error);
      toast({
        title: "Error",
        description: `Failed to ${isNewProduct ? "create" : "update"} product. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading product data...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link to="/admin/products">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">
          {isNewProduct ? "Add New Product" : "Edit Product"}
        </h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
            <CardDescription>
              Enter the core details about your product
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="title">Product Name</Label>
              <Input
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                required
                placeholder="Enter product name"
              />
            </div>
            
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                name="category"
                value={formData.category}
                onChange={handleInputChange}
                required
                placeholder="Enter category name"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="isNew"
                checked={formData.isNew}
                onCheckedChange={handleCheckboxChange}
              />
              <Label htmlFor="isNew">Mark as New Product</Label>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Images</CardTitle>
            <CardDescription>
              Add images for your product
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid w-full items-center gap-2">
              <Label htmlFor="imageUrl">Main Image URL</Label>
              <Input
                id="imageUrl"
                name="imageUrl"
                value={formData.imageUrl}
                onChange={handleInputChange}
                required
                placeholder="Enter main image URL"
              />
            </div>
            
            <div className="grid w-full items-center gap-4">
              <Label>Additional Images (Optional)</Label>
              {formData.images.map((image, index) => (
                <Input
                  key={index}
                  value={image}
                  onChange={(e) => handleImageChange(index, e.target.value)}
                  placeholder={`Additional image URL ${index + 1}`}
                />
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Subproducts</CardTitle>
            <CardDescription>
              Add subproducts and their images
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {subproducts.map((subproduct, index) => (
                <div key={index} className="flex flex-col md:flex-row gap-3 pb-4 border-b">
                  <div className="flex-1">
                    <Label htmlFor={`subproduct-${index}`}>Subproduct Name</Label>
                    <Input
                      id={`subproduct-${index}`}
                      value={subproduct.name}
                      onChange={(e) => handleSubproductChange(index, 'name', e.target.value)}
                      placeholder="Enter subproduct name"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor={`subproduct-image-${index}`}>Image URL (Optional)</Label>
                    <Input
                      id={`subproduct-image-${index}`}
                      value={subproduct.imageUrl}
                      onChange={(e) => handleSubproductChange(index, 'imageUrl', e.target.value)}
                      placeholder="Enter image URL"
                    />
                  </div>
                  <div className="flex items-end mt-2 md:mt-0">
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm"
                      onClick={() => removeSubproduct(index)} 
                      disabled={subproducts.length <= 1}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              ))}
              
              <Button
                type="button"
                variant="outline"
                onClick={addSubproduct}
              >
                Add Subproduct
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end gap-4">
          <Button variant="outline" type="button" asChild>
            <Link to="/admin/products">Cancel</Link>
          </Button>
          <Button type="submit" disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Save Product
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ProductFormPage;
