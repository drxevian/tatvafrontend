import Hero from "@/src/frontend/components/Hero";
import StatsSection from "@/src/frontend/components/StatsSection";
import { 
  Activity, Briefcase, Building, Construction, Cog, Gauge, CheckCircle,
  Map, ShoppingBag 
} from "lucide-react";
import ServicesList from "@/src/components/services/ServicesList";
import ServicesHeader from "@/src/components/services/ServicesHeader";
import ServiceDetailsSection from "@/src/components/services/ServiceDetailsSection";
import CallToAction from "@/src/components/services/CallToAction";

const ServicesPage = () => {
  const services = [
    {
      title: "Project Planning",
      description: "Comprehensive planning services including plant layout, piping layout, wiring layout, and instrument layout.",
      icon: <Map className="h-6 w-6" />,
      link: "/services#project-planning",
    },
    {
      title: "Trading",
      description: "Supply of mechanical, electrical, and instrumentation products as well as tools, MRO products, and more.",
      icon: <ShoppingBag className="h-6 w-6" />,
      link: "/services#trading",
    },
    {
      title: "Erection and Installation",
      description: "Professional installation services for machines, piping systems, control systems, wiring, and cable trays.",
      icon: <Construction className="h-6 w-6" />,
      link: "/services#installation",
    },
    {
      title: "Chemicals & Petrochemicals",
      description: "Specialized engineering services for the chemicals and petrochemicals industry with focus on safety and efficiency.",
      icon: <Activity className="h-6 w-6" />,
      link: "/services#chemicals",
    },
    {
      title: "Pharmaceuticals",
      description: "Engineering solutions for the pharmaceutical industry ensuring compliance with industry standards.",
      icon: <Briefcase className="h-6 w-6" />,
      link: "/services#pharma",
    },
    {
      title: "Plastic Industry",
      description: "Custom engineering solutions for the plastic industry to enhance production efficiency.",
      icon: <Cog className="h-6 w-6" />,
      link: "/services#plastic",
    },
    {
      title: "Ceramic Industry",
      description: "Specialized services for ceramic manufacturing with focus on process optimization.",
      icon: <Gauge className="h-6 w-6" />,
      link: "/services#ceramic",
    },
    {
      title: "Other Industries",
      description: "Adaptable engineering services for various other industrial sectors.",
      icon: <Building className="h-6 w-6" />,
      link: "/services#other",
    },
  ];

  const serviceDetails = [
    {
      id: "project-planning",
      title: "Project Planning",
      description: "Effective project planning is the cornerstone of any successful industrial operation. Tatva Engineers specializes in the meticulous design and layout of plants, ensuring that every aspect of your facility is optimized for efficiency and safety.",
      capabilities: [
        "Plant Layout",
        "Piping Layout",
        "Wiring Layout",
        "Instrument Layout",
      ],
      icon: <Map className="h-10 w-10" />,
    },
    {
      id: "trading",
      title: "Trading",
      description: "We offer comprehensive trading services, supplying a wide range of high-quality materials and equipment necessary for your industrial operations.",
      capabilities: [
        "Mechanical Products: Machines, piping materials, hardware, running spare parts",
        "Electrical Products: Cables, panels, cable trays, PD, VCB, MCCB, SDF",
        "Instrumentation Products: Gauges, valves, meters",
        "Tools and Tackles: Essential tools and equipment for industrial use",
        "All MRO Products, Packing materials, stationery, and other industrial items",
      ],
      icon: <ShoppingBag className="h-10 w-10" />,
    },
    {
      id: "installation",
      title: "Erection and Installation",
      description: "Erection and installation are critical to the foundation of any industrial facility. Tatva Engineers provides comprehensive installation services across mechanical, electrical, and instrumentation domains.",
      capabilities: [
        "Machine Installation",
        "Piping Systems",
        "Control Systems",
        "Wiring and Electrical Panels",
        "Cable Trays",
      ],
      icon: <Construction className="h-10 w-10" />,
    },
    {
      id: "chemicals",
      title: "Chemicals & Petrochemicals Industry",
      description: "We provide specialized engineering solutions for the chemicals and petrochemicals industry, with a focus on safety, reliability, and efficiency.",
      capabilities: [
        "Plant design and layout",
        "Processing equipment installation",
        "Safety systems implementation",
        "Maintenance and upgrades",
        "Compliance with industry regulations",
      ],
      icon: <Activity className="h-10 w-10" />,
    },
  ];

  return (
    <>
      <Hero
        title="Engineering Services"
        subtitle="Comprehensive Solutions for Complex Challenges"
        imageUrl="https://images.unsplash.com/photo-1581093458791-9cd6747f5107?auto=format&fit=crop&q=80"
        imageAlt="Engineering services"
      />

      {/* Services Overview */}
      <section className="section-padding">
        <div className="container mx-auto px-4">
          <ServicesHeader />
          <ServicesList services={services} />
        </div>
      </section>

      {/* Stats Section */}
      <StatsSection />

      {/* Detailed Services */}
      <ServiceDetailsSection serviceDetails={serviceDetails} />

      {/* CTA Section */}
      <CallToAction />
    </>
  );
};

export default ServicesPage;
