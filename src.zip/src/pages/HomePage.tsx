import { ArrowRight, Wrench, Briefcase, Award, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@components/ui/button";
import Hero from "@components/Hero";
import ServiceCard from "@components/ServiceCard";
import TestimonialCard from "@components/TestimonialCard";
import StatsSection from "@components/StatsSection";

const HomePage = () => {
  const featuredServices = [
    {
      title: "Mechanical Engineering",
      description: "Comprehensive mechanical engineering solutions including design, analysis, and optimization for various industrial applications.",
      icon: <Wrench className="h-6 w-6" />,
      link: "/services",
    },
    {
      title: "Electrical Engineering",
      description: "Expert electrical engineering services from power systems design to control systems and automation solutions.",
      icon: <Briefcase className="h-6 w-6" />,
      link: "/services",
    },
    {
      title: "Civil Engineering",
      description: "Professional civil engineering expertise for infrastructure projects, including structural design and project management.",
      icon: <Award className="h-6 w-6" />,
      link: "/services",
    },
    {
      title: "Consulting Services",
      description: "Strategic consulting for engineering projects, helping optimize processes, costs, and outcomes.",
      icon: <Users className="h-6 w-6" />,
      link: "/services",
    },
  ];

  const testimonials = [
    {
      quote: "Tatva Engineers delivered exceptional quality in our factory automation project. Their attention to detail and technical expertise exceeded our expectations.",
      author: "Rajesh Kumar",
      role: "Operations Director",
      company: "Tata Industries",
    },
    {
      quote: "Working with Tatva Engineers transformed our manufacturing process. Their innovative solutions helped us increase productivity by 35%.",
      author: "Priya Sharma",
      role: "Plant Manager",
      company: "Reliance Manufacturing",
    },
    {
      quote: "The team at Tatva Engineers provided excellent support throughout our project. Their responsiveness and technical knowledge were invaluable.",
      author: "Amit Patel",
      role: "Chief Engineer",
      company: "Adani Power",
    },
  ];

  return (
    <>
      <Hero
        title="Engineering Excellence for a Better Tomorrow"
        subtitle="Innovative Solutions for Complex Challenges"
        description="Tatva Engineers combines expertise, innovation, and precision engineering to deliver outstanding solutions for the most complex industrial challenges."
        primaryCTA={{ text: "Explore Services", link: "/services" }}
        secondaryCTA={{ text: "Contact Us", link: "/contact" }}
        imageUrl="https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&q=80"
        imageAlt="Engineering professionals working together"
        isHomepage={true}
      />

      {/* Services Section */}
      <section className="section-padding">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Expert Services</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Discover how our comprehensive range of engineering services can help your business achieve its goals with innovative and sustainable solutions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredServices.map((service, index) => (
              <ServiceCard
                key={index}
                title={service.title}
                description={service.description}
                icon={service.icon}
                link={service.link}
              />
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild>
              <Link to="/services" className="flex items-center">
                View All Services <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <StatsSection />

      {/* About Section */}
      <section className="section-padding bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Engineering Excellence Since 2010</h2>
              <p className="text-gray-600 mb-6">
                At Tatva Engineers, we combine expertise, innovation, and technology to deliver world-class engineering solutions across multiple industries.
              </p>
              <p className="text-gray-600 mb-6">
                Our team of seasoned engineers brings decades of combined experience, ensuring that every project exceeds expectations in quality, efficiency, and innovation.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Button asChild>
                  <Link to="/about">Learn About Us</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/contact">Contact Our Team</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&q=80" 
                alt="Engineering team at work" 
                className="rounded-lg shadow-lg w-full"
              />
              <div className="absolute -bottom-6 -left-6 bg-tatva-blue text-white p-6 rounded-lg shadow-lg md:max-w-sm">
                <p className="font-medium text-lg">
                  "Our mission is to deliver engineering solutions that create lasting value for our clients and society."
                </p>
                <p className="mt-4 font-semibold">— Vikram Shah, Founder</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section-padding bg-muted">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it. Hear from the clients who have experienced our engineering excellence firsthand.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard
                key={index}
                quote={testimonial.quote}
                author={testimonial.author}
                role={testimonial.role}
                company={testimonial.company}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-tatva-blue to-tatva-teal text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Engineering Projects?</h2>
          <p className="text-lg opacity-90 max-w-2xl mx-auto mb-8">
            Partner with Tatva Engineers to bring innovation, efficiency, and excellence to your next project.
          </p>
          <Button asChild size="lg" variant="outline" className="text-white hover:text-white border-white hover:border-white bg-white/10 hover:bg-white/20">
            <Link to="/contact">Get Started Today</Link>
          </Button>
        </div>
      </section>
    </>
  );
};

export default HomePage;
